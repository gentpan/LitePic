<?php
declare(strict_types=1);

/**
 * 图库列表 API
 * GET /api/list.php?page=1&per_page=20&q=keyword&sort=date-desc
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Vary: Origin');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization, X-Requested-With');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once '../config.php';
require_once '../functions.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    error_response('仅支持 GET 请求', 405);
}

if (!is_api_request_authorized()) {
    error_response('权限不足', 403);
}

$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = max(1, min(100, (int)($_GET['per_page'] ?? 20)));
$query = trim((string)($_GET['q'] ?? ''));
$sort = (string)($_GET['sort'] ?? 'date-desc');

$images = get_uploaded_images();

if ($query !== '') {
    $images = array_values(array_filter($images, static function (string $filename) use ($query): bool {
        return mb_stripos($filename, $query) !== false;
    }));
}

switch ($sort) {
    case 'name-asc':
        usort($images, static fn (string $a, string $b): int => strcmp($a, $b));
        break;
    case 'name-desc':
        usort($images, static fn (string $a, string $b): int => strcmp($b, $a));
        break;
    case 'size-asc':
        usort($images, static function (string $a, string $b): int {
            $sa = (int)@filesize(get_file_path($a));
            $sb = (int)@filesize(get_file_path($b));
            return $sa <=> $sb;
        });
        break;
    case 'size-desc':
        usort($images, static function (string $a, string $b): int {
            $sa = (int)@filesize(get_file_path($a));
            $sb = (int)@filesize(get_file_path($b));
            return $sb <=> $sa;
        });
        break;
    case 'date-asc':
        usort($images, static function (string $a, string $b): int {
            $ta = (int)@filemtime(get_file_path($a));
            $tb = (int)@filemtime(get_file_path($b));
            return $ta <=> $tb;
        });
        break;
    case 'date-desc':
    default:
        usort($images, static function (string $a, string $b): int {
            $ta = (int)@filemtime(get_file_path($a));
            $tb = (int)@filemtime(get_file_path($b));
            return $tb <=> $ta;
        });
        break;
}

$total = count($images);
$total_pages = max(1, (int)ceil($total / $per_page));
$page = min($page, $total_pages);
$offset = ($page - 1) * $per_page;
$paged = array_slice($images, $offset, $per_page);

$items = [];
foreach ($paged as $filename) {
    $info = get_image_info($filename);
    if ($info === null) {
        continue;
    }

    $items[] = [
        'filename' => (string)$info['filename'],
        'original_name' => (string)($info['original_name'] ?? $info['filename']),
        'url' => (string)$info['url'],
        'thumb_url' => (string)($info['thumb_url'] ?? $info['url']),
        'size' => (int)($info['size'] ?? 0),
        'size_text' => format_filesize((int)($info['size'] ?? 0)),
        'dimensions' => (string)($info['dimensions'] ?? ''),
        'time' => (int)($info['time'] ?? 0),
        'time_text' => date('Y-m-d H:i', (int)($info['time'] ?? time())),
    ];
}

success_response([
    'data' => [
        'items' => $items,
        'pagination' => [
            'page' => $page,
            'per_page' => $per_page,
            'total' => $total,
            'total_pages' => $total_pages,
        ],
    ],
]);

