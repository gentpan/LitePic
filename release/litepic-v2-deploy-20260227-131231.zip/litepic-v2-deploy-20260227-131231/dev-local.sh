#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8080}"

mkdir -p uploads logs data
touch data/visit_count.txt

# 从 .env 读取上传上限（默认 20MB）
MAX_FILE_SIZE_MB="$(awk -F= '/^MAX_FILE_SIZE_MB=/{gsub(/"/,"",$2); print $2}' .env 2>/dev/null | tail -n1)"
if [[ -z "${MAX_FILE_SIZE_MB}" ]]; then
  MAX_FILE_SIZE_MB=20
fi
if ! [[ "${MAX_FILE_SIZE_MB}" =~ ^[0-9]+$ ]]; then
  MAX_FILE_SIZE_MB=20
fi
if (( MAX_FILE_SIZE_MB < 1 )); then
  MAX_FILE_SIZE_MB=1
fi
if (( MAX_FILE_SIZE_MB > 50 )); then
  MAX_FILE_SIZE_MB=50
fi
POST_MAX_SIZE_MB=$((MAX_FILE_SIZE_MB + 2))
if (( POST_MAX_SIZE_MB > 52 )); then
  POST_MAX_SIZE_MB=52
fi

echo "Starting LitePic at http://${HOST}:${PORT}"
echo "Tip: export ADMIN_API_KEY='your-key' before start for local override."
echo "Upload limits: upload_max_filesize=${MAX_FILE_SIZE_MB}M post_max_size=${POST_MAX_SIZE_MB}M"

php \
  -d "upload_max_filesize=${MAX_FILE_SIZE_MB}M" \
  -d "post_max_size=${POST_MAX_SIZE_MB}M" \
  -d "max_file_uploads=50" \
  -d "memory_limit=256M" \
  -S "${HOST}:${PORT}" -t "$ROOT_DIR" "$ROOT_DIR/router.php"
