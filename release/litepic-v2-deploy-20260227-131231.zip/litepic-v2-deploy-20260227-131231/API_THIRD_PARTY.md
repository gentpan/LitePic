# 第三方上传 API

## Endpoint

- `POST /api/upload.php`

## 鉴权方式

二选一：

- Header: `X-API-Key: <your-key>`
- Header: `Authorization: Bearer <your-key>`

服务端会校验：

- `ADMIN_API_KEY`
- 或 `THIRD_PARTY_API_KEYS`（环境变量，逗号分隔）
- 或在 `settings.php` 的“API Token 管理”中创建的 Token

## 请求参数

使用 `multipart/form-data`，支持字段：

- `image`（单文件）
- `image[]`（多文件）
- `file`（单文件）
- `files[]`（多文件）

## 响应示例

```json
{
  "status": "success",
  "results": [
    {
      "status": "success",
      "filename": "65f0a8f4438b1.png",
      "original_name": "demo.png",
      "url": "https://your-domain.com/uploads/2026/02/65f0a8f4438b1.png"
    }
  ]
}
```

## cURL 示例

```bash
curl -X POST "https://your-domain.com/api/upload.php" \
  -H "X-API-Key: your-third-party-key" \
  -F "image=@/path/to/demo.png"
```
