#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

OUT_DIR="assets/css"
MAIN="$OUT_DIR/main.css"
MIN="$OUT_DIR/main.min.css"

if [[ ! -f "$MAIN" ]]; then
  echo "Missing $MAIN"
  exit 1
fi

perl -0777 -pe 's{/\*.*?\*/}{}gs; s/\s+/ /gs; s/\s*([{}:;,>])\s*/$1/gs; s/;}/}/gs; s/^\s+|\s+$//g' "$MAIN" > "$MIN"

echo "Built: $MIN"
