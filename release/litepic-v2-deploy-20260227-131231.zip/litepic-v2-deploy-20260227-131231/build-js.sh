#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
JS_DIR="$ROOT_DIR/assets/js"
OUT_MAIN="$JS_DIR/main.js"
OUT_MIN="$JS_DIR/main.min.js"

FILES=(
  "script.js"
  "auth.js"
  "gallery.js"
  "upload.js"
  "stats.js"
  "docs-highlight.js"
  "view-image.min.js"
)

MINIFIER=""
if command -v terser >/dev/null 2>&1; then
  MINIFIER="terser"
elif command -v esbuild >/dev/null 2>&1; then
  MINIFIER="esbuild"
fi

if [[ "${REQUIRE_MINIFIER:-0}" == "1" && -z "$MINIFIER" ]]; then
  echo "No JS minifier found. Install terser or esbuild first." >&2
  exit 1
fi

for f in "${FILES[@]}"; do
  if [[ ! -f "$JS_DIR/$f" ]]; then
    echo "Missing JS file: $JS_DIR/$f" >&2
    exit 1
  fi
done

{
  echo "/* LitePic V2 JavaScript bundle - generated $(date '+%Y-%m-%d %H:%M:%S') */"
  for f in "${FILES[@]}"; do
    echo
    echo "/* ===== $f ===== */"
    cat "$JS_DIR/$f"
    echo
  done
} > "$OUT_MAIN"

if [[ "$MINIFIER" == "terser" ]]; then
  terser "$OUT_MAIN" --compress --mangle --output "$OUT_MIN"
elif [[ "$MINIFIER" == "esbuild" ]]; then
  esbuild "$OUT_MAIN" --minify --outfile="$OUT_MIN"
else
  awk 'NF{print}' "$OUT_MAIN" > "$OUT_MIN"
fi

echo "Built: $OUT_MAIN"
echo "Built: $OUT_MIN"
