<?php
/**
 * Plugin Name: LitePic External Uploader
 * Description: Upload images to LitePic image bed and insert URL into WordPress editor.
 * Version: 1.0.0
 * Author: gentpan
 */

if (!defined('ABSPATH')) {
    exit;
}

final class LitePic_External_Uploader {
    private const OPTION_KEY = 'litepic_external_uploader_options';

    public static function init(): void {
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('admin_menu', [self::class, 'add_settings_page']);
        add_action('media_buttons', [self::class, 'render_editor_button'], 20);
        add_action('admin_footer', [self::class, 'render_footer_script']);
    }

    public static function register_settings(): void {
        register_setting('litepic_external_uploader_group', self::OPTION_KEY, [
            'type' => 'array',
            'sanitize_callback' => [self::class, 'sanitize_options'],
            'default' => [
                'endpoint' => '',
                'api_key' => '',
            ],
        ]);
    }

    public static function sanitize_options($input): array {
        $output = [
            'endpoint' => '',
            'api_key' => '',
        ];

        if (is_array($input)) {
            $output['endpoint'] = esc_url_raw(trim((string)($input['endpoint'] ?? '')));
            $output['api_key'] = sanitize_text_field((string)($input['api_key'] ?? ''));
        }

        return $output;
    }

    public static function add_settings_page(): void {
        add_options_page(
            'LitePic Uploader',
            'LitePic Uploader',
            'manage_options',
            'litepic-uploader',
            [self::class, 'render_settings_page']
        );
    }

    public static function render_settings_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $options = get_option(self::OPTION_KEY, []);
        $endpoint = esc_attr((string)($options['endpoint'] ?? ''));
        $api_key = esc_attr((string)($options['api_key'] ?? ''));
        ?>
        <div class="wrap">
            <h1>LitePic Uploader</h1>
            <p>配置你的 LitePic 第三方上传接口，编辑器可直接上传并插入图片。</p>
            <form method="post" action="options.php">
                <?php settings_fields('litepic_external_uploader_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="litepic-endpoint">API Endpoint</label></th>
                        <td>
                            <input id="litepic-endpoint" name="<?php echo esc_attr(self::OPTION_KEY); ?>[endpoint]" type="url" class="regular-text" value="<?php echo $endpoint; ?>" placeholder="https://your-domain.com/api/upload.php" />
                            <p class="description">示例：`https://你的图床域名/api/upload.php`</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="litepic-key">API Key</label></th>
                        <td>
                            <input id="litepic-key" name="<?php echo esc_attr(self::OPTION_KEY); ?>[api_key]" type="text" class="regular-text" value="<?php echo $api_key; ?>" />
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function render_editor_button(): void {
        if (!current_user_can('upload_files')) {
            return;
        }

        echo '<button type="button" class="button" id="litepic-upload-btn">上传到 LitePic</button>';
        echo '<input type="file" id="litepic-upload-input" accept="image/*" style="display:none;" />';
    }

    public static function render_footer_script(): void {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || !in_array($screen->base, ['post', 'site-editor'], true)) {
            return;
        }

        $options = get_option(self::OPTION_KEY, []);
        $endpoint = esc_js((string)($options['endpoint'] ?? ''));
        $api_key = esc_js((string)($options['api_key'] ?? ''));
        ?>
        <script>
        (function() {
            const endpoint = '<?php echo $endpoint; ?>';
            const apiKey = '<?php echo $api_key; ?>';
            const btn = document.getElementById('litepic-upload-btn');
            const input = document.getElementById('litepic-upload-input');

            if (!btn || !input) return;

            function notify(message, type) {
                if (window.wp && wp.data && wp.data.dispatch) {
                    wp.data.dispatch('core/notices').createNotice(type || 'info', message, { isDismissible: true });
                } else {
                    alert(message);
                }
            }

            function insertImage(url) {
                if (window.wp && wp.blocks && wp.data && wp.data.dispatch && wp.data.select('core/block-editor')) {
                    const imageBlock = wp.blocks.createBlock('core/image', { url: url });
                    wp.data.dispatch('core/block-editor').insertBlocks(imageBlock);
                    return;
                }

                if (typeof window.send_to_editor === 'function') {
                    window.send_to_editor('<img src="' + url + '" alt="" />');
                    return;
                }

                notify('无法插入到当前编辑器，请手动粘贴链接: ' + url, 'warning');
            }

            async function doUpload(file) {
                if (!endpoint || !apiKey) {
                    notify('请先在 设置 -> LitePic Uploader 填写 endpoint 和 API Key', 'error');
                    return;
                }

                const formData = new FormData();
                formData.append('image', file);

                btn.disabled = true;
                const oldText = btn.textContent;
                btn.textContent = '上传中...';

                try {
                    const resp = await fetch(endpoint, {
                        method: 'POST',
                        headers: {
                            'X-API-Key': apiKey
                        },
                        body: formData
                    });

                    const data = await resp.json().catch(() => null);
                    if (!resp.ok || !data) {
                        throw new Error((data && data.message) ? data.message : ('请求失败 (' + resp.status + ')'));
                    }

                    const result = Array.isArray(data.results) ? data.results[0] : null;
                    if (!result || result.status !== 'success' || !result.url) {
                        throw new Error((result && result.message) ? result.message : '上传失败');
                    }

                    insertImage(result.url);
                    notify('上传成功', 'success');
                } catch (err) {
                    notify(err.message || '上传失败', 'error');
                } finally {
                    btn.disabled = false;
                    btn.textContent = oldText;
                }
            }

            btn.addEventListener('click', function() {
                input.click();
            });

            input.addEventListener('change', function() {
                const file = input.files && input.files[0];
                if (file) {
                    doUpload(file);
                }
                input.value = '';
            });
        })();
        </script>
        <?php
    }
}

LitePic_External_Uploader::init();
